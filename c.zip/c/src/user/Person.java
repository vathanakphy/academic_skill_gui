package user;

public interface Person {
    //public
    void displayUserInfo();
}
