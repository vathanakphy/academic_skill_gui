package progress;

import java.util.Scanner;

import core.Form;
import user.Teacher;

public class TestCode {
    public static void main(String[] args) throws RuntimeException{
        Teacher t = new Teacher(null, null);
        
    }
}
 